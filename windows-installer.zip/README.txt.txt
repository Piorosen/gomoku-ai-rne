===== 오목 프로젝트 =====


1. 프로젝트 다운로드 하는 방법 : 

- 다운로드 받은 파일을 C 드라이브로 옮긴다.
- installer.bat 파일을 실행 한다.
- CMAKE 설치 할 때 사용자 계정은 current user로 설치 한다.
	- 모든 유저나 어드민 설치 할 경우 문제가 생김.
- 기다리면 끝납니다.
- Gomoku-ai.sln 파일 실행 한 뒤 Gomoku-ai 프로젝트를 실행 하면 됩니다.

== 조건 : 
1. C++ 이 설치가 되어 있어야 합니다.
2. Visual Studio 2019가 설치가 되어 있어야 합니다.

=== 설치 목록 : 
1. CMake
2. Visual Studio 2019 영어 언어팩
3. vcpkg


2. 프로젝트 정리 및 삭제 하는 방법

- remover.bat를 실행 합니다.

=== 삭제 목록 : 
1. CMake
2. Visual Studio 2019 영어 언어팩
3. vcpkg